import { IUser } from "../../types";

export interface IRootReducer {
    router: any,
    user: IUser,
}
