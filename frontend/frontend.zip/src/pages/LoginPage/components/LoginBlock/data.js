import facebookIcon from "../../../../assets/icons/facebook-icon.svg";

export const socialLinks = [
  {
    link: "https://www.facebook.com/",
    icon: facebookIcon
  }
];
