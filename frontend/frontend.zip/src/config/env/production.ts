export default {
  BASE_URL: '',
};