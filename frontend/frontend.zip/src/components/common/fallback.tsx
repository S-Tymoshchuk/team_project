import React from 'react';

export default function Fallback() {
    return (
        <div>
            Loading...
        </div>
    )
}
